/* Prototyper */
int mainMenu(void);
void printMainMenu(void);

int editMenu(FILE *, team *, int *);
int editMenu(FILE *, team *, int *);
void printEditMenu(void);
