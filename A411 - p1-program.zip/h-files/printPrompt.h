/* Prototyper */
void createTemplate(void);
int printToFile(match *, int, int, int);
void printToTerminal(match *, int, int, int);
int printProgram(match *, int, int, int);
char translateToChar(int);
int promptForFields(void);
int promptForTime(void);
void promptForFileName(char *);
void showPrintOptions(void);
