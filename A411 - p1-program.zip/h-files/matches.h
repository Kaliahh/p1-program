/* Prototyper */
void createMatches(team *, match *, int);
int createMatchesByLevel(team *, match *, int, int);
int compareMatches(const match, const match);
