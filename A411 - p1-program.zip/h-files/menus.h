/* Prototyper */
int mainMenu(void);
void printMainMenu(void);

void removeTeams(const team *, team *, const int, const int);
void addTeams(const team *, team *, const int, const int);
void changeStartingTime(team *, const char *, const int, int);
void changeEndingTime(team *, const char *, const int, int);
team *editMenu(FILE *, team *, team *, team *, int *);
